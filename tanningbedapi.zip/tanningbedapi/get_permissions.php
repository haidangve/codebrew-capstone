<?php
require 'db_config.php';
$roleId = $_POST['UserRoleID'];

$permissions = [
    'ManageClients' => 1,
    'ManageSessions' => 2,
    'User Mgt' => 3,
    'Session Control' => 4,
    'Role & Permission' => 5
];

foreach ($permissions as $name => $id) {
    $granted = isset($_POST[$name]) ? intval($_POST[$name]) : 0;

    $sql = "INSERT INTO permissionlevel (UserRoleID, PermissionID, LevelGranted)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE LevelGranted = VALUES(LevelGranted)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $roleId, $id, $granted);
    $stmt->execute();
}

echo json_encode(['success' => true]);
?>
