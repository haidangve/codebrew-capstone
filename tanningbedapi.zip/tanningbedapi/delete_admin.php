<?php
require_once 'db_config.php';
header('Content-Type: application/json');
error_reporting(0);

if (!isset($_POST['userID'], $_POST['first'], $_POST['last'], $_POST['phone'])) {
    echo json_encode(['success' => false, 'message' => 'Missing data']);
    exit;
}

$userID = $_POST['userID'];
$first = $_POST['first'];
$last = $_POST['last'];
$phone = $_POST['phone'];

$update = $conn->prepare("UPDATE user SET UserFirstName = ?, UserLastName = ?, UserPhoneNumber = ? WHERE UserID = ?");
$update->bind_param("sssi", $first, $last, $phone, $userID);
$update->execute();

echo json_encode(['success' => true]);
