<?php
require_once 'db_config.php';

header('Content-Type: application/json');
error_reporting(0); // Prevent warnings or notices from breaking JSON

if (!isset($_GET['clientTanID'])) {
    echo json_encode(['success' => false, 'message' => 'Missing clientTanID']);
    exit;
}

$clientTanID = $_GET['clientTanID'];

// Query the client based on ClientTanID
$query = $conn->prepare("SELECT c.ClientID, m.TotalAvailableMinutes
                         FROM Client c
                         JOIN ClientMinutes m ON c.ClientID = m.ClientID
                         WHERE c.ClientTanID = ?");
$query->bind_param("s", $clientTanID);
$query->execute();
$result = $query->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        'success' => true,
        'clientID' => $row['ClientID'],
        'minutes' => $row['TotalAvailableMinutes']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Client not found']);
}
