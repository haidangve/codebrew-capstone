<?php
require 'db_config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first = $_POST['first_name'];
    $last = $_POST['last_name'];
    $phone = $_POST['phone'];
    $pin = $_POST['pin'];
    $role_id = $_POST['role_id'];

    if (empty($first) || empty($last) || empty($phone) || empty($pin) || empty($role_id)) {
        echo json_encode(['error' => 'Missing required fields']);
        exit;
    }

    $prefix = strtoupper(substr($last, 0, 3));

    // Step 1: Check the RandomNumbers table
    $check_sql = "SELECT LastNumberUsed FROM RandomNumbers WHERE LastNameCharacters = ?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("s", $prefix);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($lastNumber);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();
        $newNumber = $lastNumber + 1;
    } else {
        $newNumber = 1;
    }
    $stmt->close();

    // Generate formatted IDs
    $formattedNumber = str_pad($newNumber, 3, '0', STR_PAD_LEFT);
    $clientTanID = $prefix . $formattedNumber;
    $portalID = "ADM" . $formattedNumber;

    // Step 2: Insert into Admin table
    $insert_sql = "INSERT INTO Admin (UserFirstName, UserLastName, UserPhone, ClientTanID, PortalID, UserPin, UserRoleID)
                   VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("ssssssi", $first, $last, $phone, $clientTanID, $portalID, $pin, $role_id);
    $success = $stmt->execute();
    $stmt->close();

    // Step 3: Update or insert into RandomNumbers
    if ($lastNumber !== null) {
        $update_sql = "UPDATE RandomNumbers SET LastNumberUsed = ? WHERE LastNameCharacters = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("is", $newNumber, $prefix);
    } else {
        $insert_random_sql = "INSERT INTO RandomNumbers (LastNameCharacters, LastNumberUsed) VALUES (?, ?)";
        $stmt = $conn->prepare($insert_random_sql);
        $stmt->bind_param("si", $prefix, $newNumber);
    }
    $stmt->execute();
    $stmt->close();

    if ($success) {
        echo json_encode([
            'message' => 'Admin created successfully',
            'ClientTanID' => $clientTanID,
            'PortalID' => $portalID
        ]);
    } else {
        echo json_encode(['error' => 'Failed to create admin']);
    }

} else {
    echo json_encode(['error' => 'Invalid request method']);
}
?>
