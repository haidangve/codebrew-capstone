<?php
require_once 'db_config.php';

header('Content-Type: application/json');

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$userID = $_POST['userPortalLogonID'];  // unique login ID
$phone = $_POST['phoneNumber'];
$pin = $_POST['pin'];
$roleTitle = $_POST['roleTitle']; // 'Admin' or 'Staff'

// 1. Get UserRoleID
$stmt = $conn->prepare("SELECT UserRoleID FROM UserRole WHERE UserRoleTitle = ?");
$stmt->bind_param("s", $roleTitle);
$stmt->execute();
$result = $stmt->get_result();

if (!$roleRow = $result->fetch_assoc()) {
    echo json_encode(['success' => false, 'message' => 'Role not found']);
    exit;
}

$roleID = $roleRow['UserRoleID'];

// 2. Insert User
$stmt = $conn->prepare("INSERT INTO User (UserFirstName, UserLastName, UserPortalLogonID, UserPhoneNumber, UserRoleID, UserActive)
                        VALUES (?, ?, ?, ?, ?, 1)");
$stmt->bind_param("ssssi", $firstName, $lastName, $userID, $phone, $roleID);
$stmt->execute();
$newUserID = $stmt->insert_id;

// 3. Insert into UserLogon with hashed PIN
$hashedPin = password_hash($pin, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO UserLogon (UserID, UserPin) VALUES (?, ?)");
$stmt->bind_param("is", $newUserID, $hashedPin);
$stmt->execute();

echo json_encode(['success' => true, 'userID' => $newUserID]);
