<?php
include 'db_config.php';

$portalID = $_POST['portal_id'];
$pin = $_POST['pin'];
$role = $_POST['role'];

if ($role === "user") {
    $query = "SELECT * FROM clientlogon cl
              JOIN client c ON cl.ClientID = c.ClientID
              WHERE UPPER(c.ClientTanID) = UPPER(?) AND cl.ClientPin = ? AND c.ClientActive = 1";
} else if ($role === "admin") {
    $query = "SELECT * FROM userlogon ul
              JOIN user u ON ul.UserID = u.UserID
              WHERE UPPER(u.UserPortalLogonID) = UPPER(?) AND ul.UserPin = ? AND u.UserActive = 1";
} else {
    echo "invalid role";
    exit();
}

$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $portalID, $pin);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    echo "success";
} else {
    echo "invalid";
}
?>
