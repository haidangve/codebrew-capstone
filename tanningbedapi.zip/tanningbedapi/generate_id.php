<?php
header('Content-Type: application/json');
require_once 'db_config.php';

if (!isset($_POST['last_name']) || strlen($_POST['last_name']) < 1) {
    echo json_encode(['error' => 'Missing or invalid last name']);
    exit;
}

$lastName = strtoupper(substr($_POST['last_name'], 0, 3));
$prefix = $lastName;

$sql = "SELECT LastNumberUsed FROM randomnumbers WHERE LastNameCharacters = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $prefix);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $newNumber = $row['LastNumberUsed'] + 1;

    $update = $conn->prepare("UPDATE randomnumbers SET LastNumberUsed = ? WHERE LastNameCharacters = ?");
    $update->bind_param("is", $newNumber, $prefix);
    $update->execute();
} else {
    $newNumber = 1;
    $insert = $conn->prepare("INSERT INTO randomnumbers (LastNameCharacters, LastNumberUsed) VALUES (?, ?)");
    $insert->bind_param("si", $prefix, $newNumber);
    $insert->execute();
}

$tanID = $prefix . str_pad($newNumber, 3, "0", STR_PAD_LEFT);
echo json_encode(["tan_id" => $tanID]);
?>
