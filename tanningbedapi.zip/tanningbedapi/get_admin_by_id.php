<?php
require_once 'db_config.php';
header('Content-Type: application/json');
error_reporting(0);

if (!isset($_POST['userID'])) {
    echo json_encode(['success' => false, 'message' => 'Missing userID']);
    exit;
}

$userID = $_POST['userID'];

$query = $conn->prepare("SELECT UserFirstName, UserLastName, UserPhoneNumber FROM user WHERE UserID = ?");
$query->bind_param("i", $userID);
$query->execute();
$result = $query->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        'success' => true,
        'name' => $row['UserFirstName'] . ' ' . $row['UserLastName'],
        'phone' => $row['UserPhoneNumber']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Admin not found']);
}
