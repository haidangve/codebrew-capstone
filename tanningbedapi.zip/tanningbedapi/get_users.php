<?php
include 'db_config.php';

$sql = "SELECT * FROM user";
$result = $conn->query($sql);

$users = array();
while($row = $result->fetch_assoc()) {
    $users[] = $row;
}

echo json_encode($users);
$conn->close();
?>
