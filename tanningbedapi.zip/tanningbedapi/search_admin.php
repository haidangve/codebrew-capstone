<?php
require_once 'db_config.php';
header('Content-Type: application/json');
error_reporting(0);

if (!isset($_POST['userPortalLogonID'])) {
    echo json_encode(['success' => false, 'message' => 'Missing logon ID']);
    exit;
}

$logonID = $_POST['userPortalLogonID'];

$query = $conn->prepare("SELECT u.UserID, u.UserFirstName, u.UserLastName, r.UserRoleTitle
                         FROM user u
                         JOIN userrole r ON u.UserRoleID = r.UserRoleID
                         WHERE u.UserPortalLogonID = ?");
$query->bind_param("s", $logonID);
$query->execute();
$result = $query->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        'success' => true,
        'userID' => $row['UserID'],
        'name' => $row['UserFirstName'] . ' ' . $row['UserLastName'],
        'role' => $row['UserRoleTitle']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Admin not found']);
}
