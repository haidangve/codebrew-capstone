<?php
require_once 'db_config.php';
header('Content-Type: application/json');

$response = [];

if (isset($_POST['clientTanID']) && isset($_POST['minutesToAdd'])) {
    $clientTanID = $_POST['clientTanID'];
    $minutesToAdd = (int)$_POST['minutesToAdd'];

    $stmt = $conn->prepare("UPDATE ClientMinutes m
                            JOIN Client c ON c.ClientID = m.ClientID
                            SET m.TotalAvailableMinutes = m.TotalAvailableMinutes + ?
                            WHERE c.ClientTanID = ?");
    if ($stmt) {
        $stmt->bind_param("is", $minutesToAdd, $clientTanID);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $response = ['success' => true, 'message' => 'Minutes added successfully.'];
        } else {
            $response = ['success' => false, 'message' => 'Client not found or no change made.'];
        }

        $stmt->close();
    } else {
        $response = ['success' => false, 'message' => 'Database error.'];
    }
} else {
    $response = ['success' => false, 'message' => 'Missing parameters.'];
}

echo json_encode($response);
$conn->close();
?>
