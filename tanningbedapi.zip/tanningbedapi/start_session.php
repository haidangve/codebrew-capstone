<?php
include 'db_connect.php';

if (isset($_GET['tanID']) && isset($_GET['sessionDuration']) && isset($_GET['delay'])) {
    $tanID = $_GET['tanID'];
    $sessionDuration = intval($_GET['sessionDuration']);
    $delay = intval($_GET['delay']);

    // Get ClientID from TanID
    $stmt = $conn->prepare("SELECT ClientID FROM Client WHERE ClientTanID = ?");
    $stmt->bind_param("s", $tanID);
    $stmt->execute();
    $stmt->bind_result($clientID);

    if ($stmt->fetch()) {
        $stmt->close();

        // Insert session record
        $insert = $conn->prepare("
            INSERT INTO TanningSession (
                ClientID, 
                TanningSessionStartDate, 
                TanningSessionStartTime, 
                TanningSessionTimeEntered, 
                TanningSessionStartDelay
            ) VALUES (?, CURDATE(), CURTIME(), ?, ?)
        ");
        $insert->bind_param("iii", $clientID, $sessionDuration, $delay);

        if ($insert->execute()) {
            echo "Session recorded. Tanning bed will start after $delay minutes.";
        } else {
            echo "Failed to log session.";
        }

        $insert->close();
    } else {
        echo "TanID not found.";
    }

    $conn->close();
} else {
    echo "Required parameters not set.";
}
?>
