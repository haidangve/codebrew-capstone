<?php
require_once 'db_config.php';
header('Content-Type: application/json');
error_reporting(0);

if (!isset($_POST['clientTanID'])) {
    echo json_encode(['success' => false, 'message' => 'Missing clientTanID']);
    exit;
}

$tanID = $_POST['clientTanID'];

$query = $conn->prepare("SELECT c.ClientID, c.ClientFirstName, c.ClientLastName, c.ClientPhoneNumber, m.TotalAvailableMinutes
                         FROM client c
                         JOIN clientminutes m ON c.ClientID = m.ClientID
                         WHERE c.ClientTanID = ?");
$query->bind_param("s", $tanID);
$query->execute();
$result = $query->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        'success' => true,
        'clientID' => $row['ClientID'],
        'name' => $row['ClientFirstName'] . ' ' . $row['ClientLastName'],
        'address' => 'N/A', // update if you add address field
        'phone' => $row['ClientPhoneNumber'],
        'minutes' => $row['TotalAvailableMinutes']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'User not found']);
}
