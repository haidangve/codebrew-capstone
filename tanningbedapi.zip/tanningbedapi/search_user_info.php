<?php
require_once 'db_config.php';
header('Content-Type: application/json');
error_reporting(0);

$response = [];

if (isset($_POST['searchQuery'])) {
    $search = $_POST['searchQuery'];
    $search = "%$search%";

    $stmt = $conn->prepare("
        SELECT c.ClientID, c.ClientTanID, c.ClientFirstName, c.ClientLastName, c.ClientPhoneNumber, m.TotalAvailableMinutes
        FROM Client c
        JOIN ClientMinutes m ON c.ClientID = m.ClientID
        WHERE c.ClientTanID LIKE ? OR c.ClientFirstName LIKE ? OR c.ClientLastName LIKE ?
    ");

    if ($stmt) {
        $stmt->bind_param("sss", $search, $search, $search);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $rows = [];
            while ($row = $result->fetch_assoc()) {
                $rows[] = [
                    'clientID' => $row['ClientID'],
                    'tanID' => $row['ClientTanID'],
                    'name' => $row['ClientFirstName'] . ' ' . $row['ClientLastName'],
                    'phone' => $row['ClientPhoneNumber'],
                    'minutes' => (int)$row['TotalAvailableMinutes']
                ];
            }
            $response = ['success' => true, 'data' => $rows];
        } else {
            $response = ['success' => false, 'message' => 'No users found.'];
        }

        $stmt->close();
    } else {
        $response = ['success' => false, 'message' => 'Database error.'];
    }
} else {
    $response = ['success' => false, 'message' => 'Missing search parameter.'];
}

echo json_encode($response);
$conn->close();
?>
