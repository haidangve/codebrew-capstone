<?php
include 'db_config.php';

$first = $_POST['first_name'];
$last = $_POST['last_name'];
$phone = $_POST['phone'];
$pin = $_POST['pin'];

$prefix = strtoupper(substr($last, 0, 3));
$checkSql = "SELECT LastNumberUsed FROM RandomNumbers WHERE LastNameCharacters = ?";
$stmt = $conn->prepare($checkSql);
$stmt->bind_param("s", $prefix);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $lastNumber = $row['LastNumberUsed'] + 1;
    $updateSql = "UPDATE RandomNumbers SET LastNumberUsed = ? WHERE LastNameCharacters = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("is", $lastNumber, $prefix);
    $updateStmt->execute();
} else {
    $lastNumber = 1;
    $insertSql = "INSERT INTO RandomNumbers (LastNameCharacters, LastNumberUsed) VALUES (?, ?)";
    $insertStmt = $conn->prepare($insertSql);
    $insertStmt->bind_param("si", $prefix, $lastNumber);
    $insertStmt->execute();
}

$tanID = $prefix . str_pad($lastNumber, 3, '0', STR_PAD_LEFT);
$insertUser = "INSERT INTO Client (ClientFirstName, ClientLastName, ClientTanID, ClientPhoneNumber, ClientActive)
               VALUES (?, ?, ?, ?, 1)";
$stmt = $conn->prepare($insertUser);
$stmt->bind_param("ssss", $first, $last, $tanID, $phone);
$stmt->execute();

$clientID = $stmt->insert_id;

$insertPin = "INSERT INTO ClientLogon (ClientID, ClientPin) VALUES (?, ?)";
$stmt2 = $conn->prepare($insertPin);
$stmt2->bind_param("is", $clientID, $pin);
$stmt2->execute();

echo json_encode(["success" => true, "ClientTanID" => $tanID]);
?>
