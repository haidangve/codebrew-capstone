<?php
include 'db_config.php';

$query = $_GET['query'];

$sql = "SELECT user.UserID, UserFirstName, UserLastName, UserPhoneNumber, userrole.UserRoleTitle AS RoleName
        FROM user
        JOIN userrole ON user.UserRoleID = userrole.UserRoleID
        WHERE UserFirstName LIKE ? OR UserLastName LIKE ? OR user.UserID LIKE ?";

$stmt = $conn->prepare($sql);
$search = "%$query%";
$stmt->bind_param("sss", $search, $search, $search);
$stmt->execute();
$result = $stmt->get_result();

$admins = [];
while ($row = $result->fetch_assoc()) {
    $admins[] = $row;
}

echo json_encode($admins);
$conn->close();
?>
