<?php
include 'db_config.php';

header('Content-Type: application/json');

$UserID = $_POST['UserID'] ?? null;
$UserFirstName = $_POST['UserFirstName'] ?? null;

if ($UserID && $UserFirstName) {
    $stmt = $conn->prepare("UPDATE user SET UserFirstName=? WHERE UserID=?");
    $stmt->bind_param("si", $UserFirstName, $UserID);
    
    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "User updated."]);
    } else {
        echo json_encode(["success" => false, "message" => "Update failed."]);
    }
    $stmt->close();
} else {
    echo json_encode(["success" => false, "message" => "Missing data."]);
}
$conn->close();
?>
