<?php
include 'db_connect.php';

if (isset($_GET['tanID']) && isset($_GET['sessionDuration'])) {
    $tanID = $_GET['tanID'];
    $sessionDuration = intval($_GET['sessionDuration']);

    // Simulate turning tanning bed OFF
    $bedOff = true; // Replace with actual hardware command later

    if ($bedOff) {
        // Log session
        $stmt = $conn->prepare("INSERT INTO SessionHistory (TanID, Duration, Timestamp) VALUES (?, ?, NOW())");
        $stmt->bind_param("si", $tanID, $sessionDuration);

        if ($stmt->execute()) {
            echo "Session completed. Bed turned off. Session logged.";
        } else {
            echo "Session completed but failed to log.";
        }

        $stmt->close();
    } else {
        echo "Failed to turn off tanning bed (simulated).";
    }

    $conn->close();
} else {
    echo "Required parameters not set.";
}
?>
