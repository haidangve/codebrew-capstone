<?php
require_once 'db_config.php';
header('Content-Type: application/json');

$tanID = $_GET['tanID'] ?? '';

if (empty($tanID)) {
    echo json_encode(['name' => null]);
    exit;
}

$sql = "SELECT ClientFirstName, ClientLastName FROM Client WHERE ClientTanID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $tanID);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $name = $row['ClientFirstName'] . ' ' . $row['ClientLastName'];
    echo json_encode(['name' => $name]);
} else {
    echo json_encode(['name' => null]);
}

$stmt->close();
$conn->close();
?>
