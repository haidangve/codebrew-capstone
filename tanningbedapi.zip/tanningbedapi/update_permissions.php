<?php
header("Content-Type: application/json");

if (isset($_POST['clientID'])) {
    $clientID = intval($_POST['clientID']);
    $view = isset($_POST['view']) ? 1 : 0;
    $addMinutes = isset($_POST['addMinutes']) ? 1 : 0;
    $userMgmt = isset($_POST['userMgmt']) ? 1 : 0;
    $sessionControl = isset($_POST['sessionControl']) ? 1 : 0;
    $rolePermission = isset($_POST['rolePermission']) ? 1 : 0;

    $conn = new mysqli("localhost", "your_username", "your_password", "your_database");

    if ($conn->connect_error) {
        echo json_encode(["success" => false, "message" => "Connection failed"]);
        exit;
    }

    $stmt = $conn->prepare("UPDATE AdminPermissions SET ViewPermission=?, AddMinutes=?, UserMgmt=?, SessionControl=?, RolePermission=? WHERE ClientID=?");
    $stmt->bind_param("iiiiii", $view, $addMinutes, $userMgmt, $sessionControl, $rolePermission, $clientID);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Permissions updated."]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to update permissions."]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Missing parameters."]);
}
