<?php
require_once 'db_config.php';
ob_clean();
header('Content-Type: application/json');
error_reporting(0);

$response = [];

if (isset($_POST['clientTanID'], $_POST['action'], $_POST['duration'])) {
    $clientTanID = $_POST['clientTanID'];
    $action = strtolower($_POST['action']);
    $duration = (int)$_POST['duration'];

    // Find client ID (case-insensitive)
    $stmt = $conn->prepare("
        SELECT ClientID, TotalAvailableMinutes 
        FROM Client c 
        JOIN ClientMinutes m ON c.ClientID = m.ClientID 
        WHERE LOWER(c.ClientTanID) = LOWER(?)
    ");

    if ($stmt) {
        $stmt->bind_param("s", $clientTanID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $clientID = $row['ClientID'];
            $availableMinutes = (int)$row['TotalAvailableMinutes'];

            if ($action === 'start') {
                if ($availableMinutes >= $duration) {
                    // Deduct minutes
                    $newMinutes = $availableMinutes - $duration;

                    $update = $conn->prepare("
                        UPDATE ClientMinutes 
                        SET TotalAvailableMinutes = ? 
                        WHERE ClientID = ?
                    ");

                    if ($update) {
                        $update->bind_param("ii", $newMinutes, $clientID);
                        if ($update->execute()) {
                            $response = [
                                'success' => true,
                                'message' => "Session started. Remaining minutes: $newMinutes"
                            ];
                        } else {
                            $response = ['success' => false, 'message' => 'Failed to start session (DB update failed).'];
                        }
                        $update->close();
                    } else {
                        $response = ['success' => false, 'message' => 'Failed to prepare update statement.'];
                    }
                } else {
                    $response = ['success' => false, 'message' => 'Insufficient available minutes.'];
                }
            } elseif ($action === 'cancel') {
                $response = ['success' => true, 'message' => 'Session canceled.'];
            } else {
                $response = ['success' => false, 'message' => 'Invalid action. Use start or cancel.'];
            }
        } else {
            $response = ['success' => false, 'message' => 'User not found.'];
        }

        $stmt->close();
    } else {
        $response = ['success' => false, 'message' => 'Database error: Unable to prepare statement.'];
    }
} else {
    $response = ['success' => false, 'message' => 'Missing parameters: clientTanID, action, duration.'];
}

echo json_encode($response);
$conn->close();
exit;
?>
