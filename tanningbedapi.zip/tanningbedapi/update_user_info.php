<?php
include 'db_config.php'; // Make sure this file connects to your database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $phone = $_POST['phone'];

    // Check if user exists
    $checkQuery = "SELECT * FROM Client WHERE ClientTanID = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $updates = [];
        $params = [];
        $types = '';

        if (!empty($firstName)) {
            $updates[] = "ClientFirstName = ?";
            $params[] = $firstName;
            $types .= 's';
        }
        if (!empty($lastName)) {
            $updates[] = "ClientLastName = ?";
            $params[] = $lastName;
            $types .= 's';
        }
        if (!empty($phone)) {
            $updates[] = "ClientPhoneNumber = ?";
            $params[] = $phone;
            $types .= 's';
        }

        if (!empty($updates)) {
            $sql = "UPDATE Client SET " . implode(", ", $updates) . " WHERE ClientTanID = ?";
            $params[] = $username;
            $types .= 's';

            $stmt = $conn->prepare($sql);
            $stmt->bind_param($types, ...$params);

            if ($stmt->execute()) {
                echo json_encode(["success" => true, "message" => "User updated successfully"]);
            } else {
                echo json_encode(["success" => false, "message" => "Update failed"]);
            }
        } else {
            echo json_encode(["success" => false, "message" => "No fields to update"]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "User not found"]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Invalid request"]);
}
?>
