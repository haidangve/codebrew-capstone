<?php
require_once 'db_config.php';

$stmt = $conn->prepare("SELECT ClientID, ClientPin FROM ClientLogon");
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $clientID = $row['ClientID'];
    $rawPin = $row['ClientPin'];
    $hashedPin = password_hash($rawPin, PASSWORD_DEFAULT);

    $update = $conn->prepare("UPDATE ClientLogon SET ClientPin = ? WHERE ClientID = ?");
    $update->bind_param("si", $hashedPin, $clientID);
    $update->execute();
}

echo "✅ All PINs hashed successfully!";
