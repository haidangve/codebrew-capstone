<?php
require_once('db_config.php');

$userID = isset($_GET['userID']) ? intval($_GET['userID']) : 0;

$sql = "SELECT p.PermissionID, p.PermissionName 
        FROM permissionlevel pl 
        JOIN permission p ON pl.PermissionID = p.PermissionID 
        JOIN user u ON u.UserRoleID = pl.UserRoleID
        WHERE u.UserID = ? AND pl.LevelGranted = 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();

$permissions = [];
while ($row = $result->fetch_assoc()) {
    $permissions[] = $row['PermissionName'];
}

echo json_encode($permissions);
?>
