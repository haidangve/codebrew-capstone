<?php
require_once 'db_config.php';
header('Content-Type: application/json');
error_reporting(0);

$query = $conn->query("SELECT UserID, UserFirstName, UserLastName, UserPortalLogonID FROM user WHERE UserRoleID IN (1,2)");
$admins = [];

while ($row = $query->fetch_assoc()) {
    $admins[] = [
        'UserID' => $row['UserID'],
        'name' => $row['UserFirstName'] . ' ' . $row['UserLastName'],
        'logonID' => $row['UserPortalLogonID']
    ];
}

echo json_encode($admins);
