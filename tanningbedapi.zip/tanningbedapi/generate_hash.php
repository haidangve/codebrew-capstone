<?php
echo password_hash('999999', PASSWORD_DEFAULT);
?>
