<?php
require_once 'db_config.php';
header('Content-Type: application/json');
error_reporting(0);

if (!isset($_POST['clientID'], $_POST['name'], $_POST['phone'], $_POST['minutes'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

$clientID = $_POST['clientID'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$minutes = $_POST['minutes'];

// Optional: split name
$nameParts = explode(' ', $name, 2);
$firstName = $nameParts[0];
$lastName = isset($nameParts[1]) ? $nameParts[1] : '';

$updateClient = $conn->prepare("UPDATE client SET ClientFirstName = ?, ClientLastName = ?, ClientPhoneNumber = ? WHERE ClientID = ?");
$updateClient->bind_param("sssi", $firstName, $lastName, $phone, $clientID);
$updateClient->execute();

$updateMinutes = $conn->prepare("UPDATE clientminutes SET TotalAvailableMinutes = ? WHERE ClientID = ?");
$updateMinutes->bind_param("ii", $minutes, $clientID);
$updateMinutes->execute();

echo json_encode(['success' => true]);
