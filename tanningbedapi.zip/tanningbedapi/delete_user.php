<?php
require_once 'db_config.php';
header('Content-Type: application/json');

if (!isset($_POST['clientID'])) {
    echo json_encode(['success' => false, 'message' => 'Missing clientID']);
    exit;
}

$clientID = $_POST['clientID'];

$delete = $conn->prepare("DELETE FROM client WHERE ClientID = ?");
$delete->bind_param("i", $clientID);
$delete->execute();

echo json_encode(['success' => true]);
