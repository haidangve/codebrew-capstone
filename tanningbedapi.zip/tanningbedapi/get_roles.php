<?php
header('Content-Type: application/json');
require_once('db_config.php');

$sql = "SELECT UserRoleID, UserRoleTitle FROM userrole ORDER BY UserRoleID";
$result = $conn->query($sql);

if (!$result) {
    http_response_code(500);
    echo json_encode(['error' => $conn->error]);
    exit;
}

$roles = [];
while ($row = $result->fetch_assoc()) {
    $roles[] = $row;
}

echo json_encode($roles);
?>
