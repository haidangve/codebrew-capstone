<?php
require_once 'db_config.php';

header('Content-Type: application/json');

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$phone = $_POST['phoneNumber'];
$pin = $_POST['pin'];
$initialMinutes = isset($_POST['initialMinutes']) ? (int)$_POST['initialMinutes'] : 0;

$prefix = strtoupper(substr($lastName, 0, 3));

// 1. Check RandomNumbers for prefix
$stmt = $conn->prepare("SELECT LastNumberUsed FROM RandomNumbers WHERE LastNameCharacters = ?");
$stmt->bind_param("s", $prefix);
$stmt->execute();
$result = $stmt->get_result();

$nextNumber = 1;
if ($row = $result->fetch_assoc()) {
    $nextNumber = $row['LastNumberUsed'] + 1;
}

$clientTanID = $prefix . str_pad($nextNumber, 3, '0', STR_PAD_LEFT);

// 2. Insert Client
$stmt = $conn->prepare("INSERT INTO Client (ClientFirstName, ClientLastName, ClientTanID, ClientPhoneNumber, ClientActive) VALUES (?, ?, ?, ?, 1)");
$stmt->bind_param("ssss", $firstName, $lastName, $clientTanID, $phone);
$stmt->execute();
$clientID = $stmt->insert_id;

// 3. Hash PIN and store in ClientLogon
$hashedPin = password_hash($pin, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO ClientLogon (ClientID, ClientPin) VALUES (?, ?)");
$stmt->bind_param("is", $clientID, $hashedPin);
$stmt->execute();

// 4. Add minutes
$stmt = $conn->prepare("INSERT INTO ClientMinutes (ClientID, TotalAvailableMinutes) VALUES (?, ?)");
$stmt->bind_param("ii", $clientID, $initialMinutes);
$stmt->execute();

// 5. Update or insert RandomNumbers
if ($row) {
    $stmt = $conn->prepare("UPDATE RandomNumbers SET LastNumberUsed = ? WHERE LastNameCharacters = ?");
    $stmt->bind_param("is", $nextNumber, $prefix);
} else {
    $stmt = $conn->prepare("INSERT INTO RandomNumbers (LastNameCharacters, LastNumberUsed) VALUES (?, ?)");
    $stmt->bind_param("si", $prefix, $nextNumber);
}
$stmt->execute();

echo json_encode(['success' => true, 'clientTanID' => $clientTanID]);
