<?php
require_once 'db_config.php';

$stmt = $conn->prepare("SELECT UserID, UserPin FROM UserLogon");
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $userID = $row['UserID'];
    $rawPin = $row['UserPin'];
    $hashedPin = password_hash($rawPin, PASSWORD_DEFAULT);

    $update = $conn->prepare("UPDATE UserLogon SET UserPin = ? WHERE UserID = ?");
    $update->bind_param("si", $hashedPin, $userID);
    $update->execute();
}

echo "✅ All admin/staff PINs hashed successfully!";
