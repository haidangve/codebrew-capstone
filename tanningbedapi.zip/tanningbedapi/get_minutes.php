<?php
require_once 'db_config.php';
header('Content-Type: application/json');

$tanID = $_GET['tanID'] ?? '';

$query = $conn->prepare("SELECT cm.TotalAvailableMinutes
                         FROM Client c
                         JOIN ClientMinutes cm ON c.ClientID = cm.ClientID
                         WHERE c.ClientTanID = ?");
$query->bind_param("s", $tanID);
$query->execute();
$result = $query->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode(['success' => true, 'minutes' => $row['TotalAvailableMinutes']]);
} else {
    echo json_encode(['success' => false, 'message' => 'Client not found']);
}
?>
