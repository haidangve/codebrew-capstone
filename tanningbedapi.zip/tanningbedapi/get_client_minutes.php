<?php
require_once 'db_config.php';

$clientTanID = $_POST['clientTanID'];

$stmt = $conn->prepare("SELECT cm.TotalAvailableMinutes 
                        FROM Client c
                        JOIN ClientMinutes cm ON c.ClientID = cm.ClientID
                        WHERE c.ClientTanID = ?");
$stmt->bind_param("s", $clientTanID);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode(['success' => true, 'minutes' => $row['TotalAvailableMinutes']]);
} else {
    echo json_encode(['success' => false, 'message' => 'Client not found']);
}
