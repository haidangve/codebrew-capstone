<?php
echo json_encode(["success" => true, "message" => "Connected to backend"]);
?>
